package com
import java.util
import java.util.Properties
import org.apache.kafka.clients.consumer.{ConsumerConfig, KafkaConsumer}
import scala.collection.JavaConversions._



/** A Kafka consumer
 *
 *  @constructor create a consumer with the topic, groupId and brokers.
 *  @param topic the topic name to subscribe
 *  @param groupId group id
 *  @param brokers Kafka broker list, separated by comma.
 */

class Consumer(topic: String, groupId: String, brokers: String) extends {
  val properties = new Properties()
  properties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, brokers)
  properties.put(ConsumerConfig.GROUP_ID_CONFIG, groupId)
  properties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true")
  properties.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000")
  properties.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "30000")
  properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer")
  properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer")
  val consumer = new KafkaConsumer[String, String](properties)
  consumer.subscribe(util.Arrays.asList(topic))

  /** Method to receive an event from Kafka and parse the content as JSON
   *
   *  Loads the parsed JSON into a folder.
   *  Returns an exception if unable to parse the JSON
   */
  def receiveMessages(): Unit = {
        while (true) {
          val records = consumer.poll(Long.MaxValue)
          val jsonServices = new JsonServices
          for (message <- records) {
            try {
              val jsonMessage = jsonServices.parseJSON(message.value())
              val user = jsonMessage.user
              val companies = jsonMessage.clicks.map(_.company)
              val parsedEvent = ParsedEvent(user, companies)
              System.out.println(parsedEvent)
              jsonServices.writeJSON(s"${user}", parsedEvent)

            }
            catch {
              case e: Exception =>
                System.out.println("Cannot parse message: " + message.value())
                jsonServices.writeError(message.value())
            }
          }
        }
      }
}

object Consumer extends App {

  val consumer = new Consumer(topic = args(0), groupId = args(1),brokers = args(2))
  consumer.receiveMessages()

}


