package com

import java.io.{File, FileOutputStream, PrintWriter}
import java.text.SimpleDateFormat
import java.util.Date
import net.liftweb.json.Serialization.write
import net.liftweb.json.{DefaultFormats, _}

/** A Class that contains JSON services */

case class JsonServices() {
  implicit val formats = DefaultFormats


/** JSON parser. Parse the JSON message as an Event class
 *
 * @param jsonString JSON string
 * @return parsed JSON as an event Class
 */
  def parseJSON(jsonString: String): event =  {
    val parsedJson = parse(jsonString)
    parsedJson.extract[event]
  }


  /** JSON writer. Writes the parsed and
   *  processed JSON to a file
   *
   * @param username event user name
   * @param event JSON parsed as an event class
   */
  def writeJSON(username: String, event: ParsedEvent): Unit = {
    val filename = s"//output///clicks_${username}.json"
    val jsonString = write(event)
    val file = new File(filename)
    fileWrite(file, jsonString)
  }

  /** Error writer. Writes a message that failed
   *  to be parsed into to a file
   *
   * @param errorMsg content of the message
   */
  def writeError(errorMsg: String): Unit = {
    val timestamp = new SimpleDateFormat("YYYYMMdd_HHmmss").format(new Date)
    val filename = s"//output///error///error_${timestamp}.txt"
    val file = new File(filename)
    fileWrite(file, errorMsg)
  }

  /** Method to write an message to a file
   *
   * @param file file path
   * @param output content of the message
   */
  def fileWrite(file: File, output: String): Unit = {
    val writer = new PrintWriter(new FileOutputStream(file, true))
    writer.write(output)
    writer.write("\r\n");
    writer.close()
  }
}

case class event(event_type: String,occurred_at: String,user: String,clicks: List[clicksInfo])

case class clicksInfo(target: String,company: String,url: String)

case class ParsedEvent(user: String, companies: List[String])
